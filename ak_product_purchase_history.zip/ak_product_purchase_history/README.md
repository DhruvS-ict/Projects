Odoo 15.0 Community

Installation 
============
* Install the Application => Apps -> Product Purchase History (Technical Name: ak_product_purchase_history)



Product Purchase History
==================================
* With this app, one can able to view the history of purchase order for particular product on clicking of button.


Steps
=====
* Go to Purchase after installing the module and click the button inside purchase order_line for that particular product to see the purchase history with total order, supplier and date-range.

15.0.1.0.0
===========
This app is only valid in odoo version 15.0.1.0.0 community

