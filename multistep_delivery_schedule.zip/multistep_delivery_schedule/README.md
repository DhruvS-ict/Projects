Odoo 15.0 Community, Enterprise

Installation 
============
* Install the Application => Apps -> 



Product Purchase History
==================================
* 


Steps
=====
*

15.0.1.0.0
===========
This app is only valid in odoo version 15.0.1.0.0 community & enterprise

