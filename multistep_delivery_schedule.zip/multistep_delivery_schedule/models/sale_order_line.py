# -*- coding: utf-8 -*-
# Part of Odoo, Aktiv Software.
# See LICENSE file for full copyright & licensing details.
"""import models, fields and api from odoo"""
from odoo import models, fields, api
from datetime import timedelta


class SaleOrderLine(models.Model):
    """created class to define wizard action in functions."""
    _inherit = "sale.order.line"

    def _action_launch_stock_rule(self):
        if self.order_id.multistep_delivery:
            picking_type = self.env["stock.picking.type"].search(
                [
                    ("company_id", "=", self.company_id.id),
                    ("code", "=", 'outgoing'),
                ]
            )
            for line in self.order_id.delivery_ids:
                values = {
                    "partner_id": self.order_id.partner_shipping_id.id,
                    "picking_type_id": picking_type.id,
                    "origin": self.order_id.name,
                    "owner_id": self.order_id.partner_id.id,
                    "location_id": picking_type.default_location_src_id.id,
                    "location_dest_id": picking_type.default_location_dest_id.id,
                }

                receipt = self.env["stock.picking"].create(values)
                receipt.write(
                    {
                        "move_ids_without_package": [
                            (
                                0,
                                0,
                                {
                                    "name": line.sale_line_id.product_id.name,
                                    "product_id": line.sale_line_id.product_id.id,
                                    "product_uom": line.sale_line_id.product_id.uom_id.id,
                                    "product_uom_qty": line.quantity,
                                    "location_id": receipt.location_id.id,
                                    "location_dest_id": receipt.location_dest_id.id,
                                    "group_id": self.order_id.procurement_group_id.id,
                                },
                            )
                            for line in line.delivery_schedule_ids
                        ],
                    }
                )
                # print("\n~~~~~~~move_line_ids_without_package ", receipt.move_line_ids_without_package, "\n")
                receipt.action_confirm()
        else:
            return super(SaleOrderLine, self)._action_launch_stock_rule()
